dict_names_links = {
        'Календарь абитуриента': 'https://priem.mai.ru/calendar/',
        'Калькулятор ЕГЭ: узнайте свои шансы поступления': 'https://priem.mai.ru/base/programs/calculator/',
        'Программы': 'https://priem.mai.ru/base/programs',
        'Подача документов': 'https://priem.mai.ru/base/apply/',
        'Индивидуальные достижения': 'https://priem.mai.ru/base/achievements/'
}